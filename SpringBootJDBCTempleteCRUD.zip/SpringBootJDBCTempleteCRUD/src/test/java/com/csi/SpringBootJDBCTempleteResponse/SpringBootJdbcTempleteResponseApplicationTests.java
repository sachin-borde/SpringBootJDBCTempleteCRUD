package com.csi.SpringBootJDBCTempleteResponse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdbcTempleteResponseApplicationTests {

	@Test
	void contextLoads() {
	}

}
