package com.csi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.csi.model.Employee;

@Component
public class EmployeeDaoIMPL implements EmployeeDao {

	@Autowired
	JdbcTemplate jdbcTemplete;

	public static final String saveData = "insert into Employee (empName,empSalary,empJoinDate)values(?,?,?)";

	public static final String saveAllData = "insert into Employee (empName,empSalary,empJoinDate)values(?,?,?)";

	public static final String getDataById = "select * from employee where empId=?";

	public static final String getAllData = "select * from Employee";

	public static final String updateData = "update Employee set empName=?,empSalary=?,empJoinDate=? where empId=?";

	public static final String deleteDataById = "delete from Employee where empId=? ";

	public static final String deleteAllData = "delete from employee";

	private static final BeanPropertyRowMapper Employee = null;

	@Override
	public void saveData(Employee employee) {
		jdbcTemplete.update(saveData, employee.getEmpName(), employee.getEmpSalary(), employee.getEmpJoinDate());
	}

	@Override
	public void saveAllData(List<Employee> employee) {
		for (Employee ee : employee) {
			jdbcTemplete.update(saveAllData, ee.getEmpName(), ee.getEmpSalary(), ee.getEmpJoinDate());
		}
	}

	@Override
	public Employee getDataById(int empId) {
		return jdbcTemplete.queryForObject(getDataById, new Object[] { empId },
				new BeanPropertyRowMapper<Employee>(Employee.class));
	}

	@Override
	public List<Employee> getAllData() {
		return jdbcTemplete.query(getAllData, new RowMapper<Employee>() {
			public Employee mapRow(ResultSet rs, int empId) throws SQLException {
				Employee e = new Employee();
				e.setEmpId(rs.getInt(1));
				e.setEmpName(rs.getString(2));
				e.setEmpSalary(rs.getDouble(3));
				e.setEmpJoinDate(rs.getDate(4));
				return e;
			}
		});
	}

	@Override
	public void updateData(int empId, Employee employee) {
		jdbcTemplete.update(updateData, employee.getEmpName(), employee.getEmpSalary(), employee.getEmpJoinDate(),
				empId);
	}

	@Override
	public void deleteDataById(int empId) {
		jdbcTemplete.update(deleteDataById, empId);
	}

	@Override
	public void deleteAllData() {
		jdbcTemplete.update(deleteAllData);
	}

}
