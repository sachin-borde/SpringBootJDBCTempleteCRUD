package com.csi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbcTempleteEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJdbcTempleteEmployeeApplication.class, args);
	}

}
